# University Programs Finder
Using this app user can be able see university offering programs based on choosing study level such as Undergraduate, Graduate and Diploma.

# Application Screenshots

1. Main Screen
   
![image](https://github.com/user-attachments/assets/1995bdbf-b113-420d-bc59-47bd6ef3bda7)

2. Undergraduate Programs Screen
   
![image](https://github.com/user-attachments/assets/a35d614a-ccb9-4643-8f19-d28eba8565c2)

3. Graduate Programs Screen
   
 ![image](https://github.com/user-attachments/assets/b82f089c-7f1c-4ea6-ac10-3bbe9f6915d5)

4. Diploma Programs Screen

![image](https://github.com/user-attachments/assets/8e9163a8-09a3-4d90-b63e-a87167a4e402)

